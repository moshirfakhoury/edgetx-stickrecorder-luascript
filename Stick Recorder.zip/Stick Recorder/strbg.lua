-------------------------------------------------
-- CONSTANTS
-------------------------------------------------

local switches = {"SA","SB","SC","SD","SE","SF","SG","SH"}

local GV_INDEX = 5
local GV_INDEX2 = 6

local FM_ARM_IDX  = 5
local FM_ARM_VAL  = 6
local FM_MOTOR_IDX= 7
local FM_MOTOR_VAL= 8

local FM_SWITCH_IDX= 7
local FM_SWITCH_VAL= 8

local basePath = "/SCRIPTS/TOOLS/StickRecorder/"

local LOG_INTERVAL = 10 -- 10 rows per second

-------------------------------------------------
-- STATE
-------------------------------------------------

local lastOn = nil
local file = nil
local lastLogTime = 0

-------------------------------------------------
-- TIME HELPERS
-------------------------------------------------

local function nowTime()
  local t = getDateTime()
  local ms = (getTime() % 100) * 10
  return string.format("%02d:%02d:%02d.%03d", t.hour, t.min, t.sec, ms)
end

local function nowDate()
  local t = getDateTime()
  return string.format("%04d-%02d-%02d", t.year, t.mon, t.day)
end

local function fileTimestamp()
  local t = getDateTime()
  return string.format("%04d%02d%02d_%02d%02d%02d",
    t.year,t.mon,t.day,t.hour,t.min,t.sec)
end

-------------------------------------------------
-- READ GLOBALS
-------------------------------------------------

local function readGV()

  local motorIdx = tonumber(model.getGlobalVariable(GV_INDEX, FM_MOTOR_IDX)) or 1
  local motorVal = tonumber(model.getGlobalVariable(GV_INDEX, FM_MOTOR_VAL)) or 1024

  local armIdx   = tonumber(model.getGlobalVariable(GV_INDEX, FM_ARM_IDX)) or 0
  local armVal   = tonumber(model.getGlobalVariable(GV_INDEX, FM_ARM_VAL)) or 1024

  local switchIdx   = tonumber(model.getGlobalVariable(GV_INDEX2, FM_SWITCH_IDX)) or 0
  local switchVal   = tonumber(model.getGlobalVariable(GV_INDEX2, FM_SWITCH_VAL)) or 1024

  return motorIdx, motorVal, armIdx, armVal, switchIdx, switchVal
end

-------------------------------------------------
-- START LOGGING
-------------------------------------------------

local function startLog()

  local info = model.getInfo()
  if not info then return end

  local name = info.name .. "_" .. fileTimestamp() .. ".txt"

  local path = basePath .. name

  file = io.open(path,"w")

  if file then
    io.write(file,"date,time,ch1,ch2,ch3,ch4,motor,arm\n")
  end

end

-------------------------------------------------
-- STOP LOGGING
-------------------------------------------------

local function stopLog()

  if file then
    io.close(file)
    file = nil
  end

end

-------------------------------------------------
-- WRITE STICK DATA
-------------------------------------------------

local function logSticks()

  if not file then return end

  local ch1 = getValue("ail") or 0
  local ch2 = getValue("ele") or 0
  local ch3 = getValue("thr") or 0
  local ch4 = getValue("rud") or 0

  local motorIdx = tonumber(model.getGlobalVariable(GV_INDEX, FM_MOTOR_IDX)) or 1
  local motorRaw = getValue(switches[motorIdx]) or 0

  local armIdx = tonumber(model.getGlobalVariable(GV_INDEX, FM_ARM_IDX)) or 0
  local armRaw = (armIdx >= 1) and (getValue(switches[armIdx]) or 0) or 0

  local motorState = (motorRaw > 0) and 1024 or -1024
  local armState   = (armIdx >= 1 and armRaw > 0) and 1024 or -1024

  local line = string.format(
    "%s,%s,%d,%d,%d,%d,%d,%d\n",
    nowDate(),
    nowTime(),
    ch1,ch2,ch3,ch4,
    motorState,
    armState
  )

  io.write(file,line)

end

-------------------------------------------------
-- MAIN LOOP
-------------------------------------------------

local function run()

  local motorIdx, motorVal, armIdx, armVal, switchIdx, switchVal = readGV()

  -------------------------------------------------
  -- enable
  -------------------------------------------------

  local switchRaw = getValue(switches[switchIdx]) or 0


  local enableOn =
      (switchVal > 0 and switchRaw > 0) or
      (switchVal < 0 and switchRaw < 0)
  
  if lastOn == nil then
    lastOn = enableOn
    return
  end

  if enableOn and not lastOn then
    startLog()
  end

  if not enableOn and lastOn then
    stopLog()
  end

  if enableOn and file then
  
    local now = getTime()

    if now - lastLogTime > LOG_INTERVAL then
      logSticks()
      lastLogTime = now
    end

  end

  lastOn = enableOn

end

-------------------------------------------------

return { run = run }