
local toolName = "TNS|Stick Recorder|TNE"

-------------------------------------------------
-- CONSTANTS
-------------------------------------------------

local switches = {"SA","SB","SC","SD","SE","SF","SG","SH"}

local GV_INDEX = 5
local GV_INDEX2 = 6

local FM_ARM_IDX   = 5
local FM_ARM_VAL   = 6
local FM_MOTOR_IDX = 7
local FM_MOTOR_VAL = 8

local FM_SWITCH_IDX = 7
local FM_SWITCH_VAL = 8

local playbackData = {}
local playbackIndex = 1
local lastFrameTime = 0
local playbackSpeed = 10 
local playbackStartTime = 0
local loading = false
local fileHandle = nil
local buffer = ""
local isPlaying = true
local pausedTime = 0

local baseTime = nil
local m10 = 0
local m1  = 0
local s10 = 0
local s1  = 0

-------------------------------------------------
-- PATH
-------------------------------------------------

local basePath = "/SCRIPTS/TOOLS/StickRecorder/"

-------------------------------------------------
-- SPLASH
-------------------------------------------------

local splashStart = getTime()
local splashBmp   = bitmap.open(basePath .. "sr1.png")
local SPLASH_TIME = 400

-------------------------------------------------
-- STATE
-------------------------------------------------

local page = 1
local cursor = 1
local loaded = false

local message = ""

local motorIdx = 1
local motorVal = 1024

local armIdx = 0
local armVal = 1024

local switchIdx = 1
local switchVal = 1024

-------------------------------------------------
-- FILE BROWSER STATE
-------------------------------------------------

local logPath = "/SCRIPTS/TOOLS/StickRecorder"

local files = {}
local fileScroll = 1
local selectedFile = nil

local fileFilter = 1 -- 1 = last 20, 2 = all

-------------------------------------------------
-- DRAW HELPERS
-------------------------------------------------

local function drawRow(y,label,value,sel)
  lcd.drawText(40,y,label)
  lcd.drawText(320,y,tostring(value), sel and INVERS or 0)
end

-------------------------------------------------
-- STICK MAPPING
-------------------------------------------------
local function mapStick(value, center, size)
  return center + (value / 1024) * (size/2)
end

-------------------------------------------------
-- FORMAT TIME
-------------------------------------------------
local function formatTime(ms)
  local totalSeconds = math.floor(ms / 1000)
  local minutes = math.floor(totalSeconds / 60)
  local seconds = totalSeconds % 60
  local millis = ms % 1000

  return string.format("%02d:%02d.%03d", minutes, seconds, millis)
end

-------------------------------------------------
-- TIME SELECTION
-------------------------------------------------
local function jumpToTime(targetMs)

  for i = 1, #playbackData do
    if playbackData[i].time >= targetMs then
      playbackIndex = i

      playbackStartTime = getTime() - (playbackData[i].time / 10)

      return
    end
  end

  playbackIndex = #playbackData
end
-------------------------------------------------
-- SCAN LOG FILES
-------------------------------------------------

local function scanFiles()

  files = {}

  local list = dir(logPath)

  if not list then return end

  for name in list do
    if string.find(name, "%.txt$") then
      files[#files+1] = name
    end
  end

  table.sort(files, function(a,b) return a>b end)

  if fileFilter == 1 and #files > 20 then
    local temp = {}

    for i=1,20 do
      temp[i] = files[i]
    end

    files = temp
  end

  fileScroll = 1
end

-------------------------------------------------
-- GLOBAL STORAGE
-------------------------------------------------

local function saveGV()

  model.setGlobalVariable(GV_INDEX, FM_MOTOR_IDX, motorIdx)
  model.setGlobalVariable(GV_INDEX, FM_MOTOR_VAL, motorVal)
  model.setGlobalVariable(GV_INDEX2, FM_SWITCH_IDX, switchIdx)
  model.setGlobalVariable(GV_INDEX2, FM_SWITCH_VAL, switchVal)

  if armIdx > 0 then
    model.setGlobalVariable(GV_INDEX, FM_ARM_IDX, armIdx)
    model.setGlobalVariable(GV_INDEX, FM_ARM_VAL, armVal)
  else
    model.setGlobalVariable(GV_INDEX, FM_ARM_IDX, 0)
    model.setGlobalVariable(GV_INDEX, FM_ARM_VAL, 0)
  end

  message = "Saved"
end


local function loadGV()

  motorIdx = model.getGlobalVariable(GV_INDEX, FM_MOTOR_IDX) or motorIdx
  motorVal = model.getGlobalVariable(GV_INDEX, FM_MOTOR_VAL) or motorVal

  armIdx = model.getGlobalVariable(GV_INDEX, FM_ARM_IDX) or 0
  armVal = model.getGlobalVariable(GV_INDEX, FM_ARM_VAL) or 1024

  switchIdx = model.getGlobalVariable(GV_INDEX2, FM_SWITCH_IDX) or switchIdx
  switchVal = model.getGlobalVariable(GV_INDEX2, FM_SWITCH_VAL) or switchVal
end

-------------------------------------------------
-- PROCESS PLAYBACK
-------------------------------------------------
local function processPlaybackFile()

  if not loading or not fileHandle then return end

  local chunk = io.read(fileHandle, 128)

  -------------------------------------------------
  -- END OF FILE
  -------------------------------------------------

  if not chunk or chunk == "" then
    if buffer ~= "" then
      buffer = buffer .. "\n"
    end
    loading = false
    playbackStartTime = getTime()
    playbackIndex = 1

  else
    buffer = buffer .. chunk
  end

  -------------------------------------------------
  -- PROCESS BUFFER
  -------------------------------------------------

  while true do

    local nl = string.find(buffer, "\n", 1, true)
    if not nl then break end

    local line = string.sub(buffer, 1, nl-1)
    buffer = string.sub(buffer, nl+1)

    -- skip header
    if not string.find(line, "date") then

      local parts = {}

      for value in string.gmatch(line, "([^,]+)") do
        parts[#parts+1] = value
      end

      if #parts >= 6 then

        local h,m,s,ms = string.match(parts[2], "(%d+):(%d+):(%d+)%.(%d+)")

        local timeMs = 0

        if h then
          timeMs =
            tonumber(h)*3600000 +
            tonumber(m)*60000 +
            tonumber(s)*1000 +
            tonumber(ms or 0)

        if not baseTime then
          baseTime = timeMs
        end

        timeMs = timeMs - baseTime
      end

        playbackData[#playbackData+1] = {
          time = timeMs,
          ch1 = tonumber(parts[3]) or 0,
          ch2 = tonumber(parts[4]) or 0,
          ch3 = tonumber(parts[5]) or 0,
          ch4 = tonumber(parts[6]) or 0,
          motor = tonumber(parts[7]) or 0,
          arm = tonumber(parts[8]) or 0,
          fm    = tonumber(parts[9]) or 0
        }

      end

    end

  end

  -------------------------------------------------
  -- CLOSE FILE WHEN DONE
  -------------------------------------------------

  if not loading and fileHandle then
    io.close(fileHandle)
    fileHandle = nil
  end

end

-------------------------------------------------
-- MAIN
-------------------------------------------------

local function run(event)

  if splashBmp and (getTime() - splashStart < SPLASH_TIME) then
    lcd.clear()
    lcd.drawBitmap(splashBmp,0,0)
    return 0
  end

  if not loaded then
    loadGV()
    loaded = true
  end

  lcd.clear()

  if loading then
    processPlaybackFile()
  end
-------------------------------------------------
-- PAGE 1 : SETUP
-------------------------------------------------

if page == 1 then

  lcd.drawText(LCD_W/2,15,"Stick Recorder Setup",DBLSIZE + CENTER)
  lcd.drawLine(10,55,LCD_W-10,55,SOLID,0)

  local y=70
  local s=22

  drawRow(y+s*0,"Motor Switch",switches[motorIdx],cursor==1)
  drawRow(y+s*1,"Motor Position",motorVal,cursor==2)

  drawRow(y+s*2,"Arm Switch",armIdx==0 and "DISABLED" or switches[armIdx],cursor==3)
  drawRow(y+s*3,"Arm Position",armVal,cursor==4)

  drawRow(y+s*4,"Enable Switch",switches[switchIdx],cursor==5)
  drawRow(y+s*5,"Enable Position",switchVal,cursor==6)

  drawRow(y+s*7,"Next Page","ENTER",cursor==8)

  lcd.drawText(40,250,message,SMLSIZE)
  lcd.drawText(LCD_W-70,250,"Page 1/4",SMLSIZE)

  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then cursor=cursor%8+1 end
  if event==EVT_VIRTUAL_PREV then cursor=(cursor-2)%8+1 end

  if event==EVT_VIRTUAL_ENTER then

    if cursor==1 then
      motorIdx=motorIdx%#switches+1
      saveGV()

    elseif cursor==2 then
      motorVal=(motorVal==1024 and -1024 or 1024)
      saveGV()

    elseif cursor==3 then
      armIdx=(armIdx+1)%(#switches+1)
      saveGV()

    elseif cursor==4 then
      armVal=(armVal==1024 and -1024 or 1024)
      saveGV()

    elseif cursor==5 then
      switchIdx=(switchIdx+1)%(#switches+1)
      saveGV()

    elseif cursor==6 then
      switchVal=(switchVal==1024 and -1024 or 1024)
      saveGV()

    elseif cursor==8 then
      page=2
      cursor=1
      return 0
    end
  end
end

-------------------------------------------------
-- PAGE 2 : INFO
-------------------------------------------------

if page == 2 then

  lcd.drawText(LCD_W/2,15,"Recorder Info",DBLSIZE + CENTER)
  lcd.drawLine(10,55,LCD_W-10,55,SOLID,0)

  local y=65
  local s=20
  local rows=7

  -------------------------------------------------
  -- INFO TEXT
  -------------------------------------------------

  drawRow(y+s*0,"Recording Interval","0.2 sec",false)
  drawRow(y+s*1,"Channels","CH1 CH2 CH3 CH4",false)

  -------------------------------------------------
  -- BOTTOM BUTTONS (same positioning as Page 3)
  -------------------------------------------------

  drawRow(y+s*(rows+1),"Next Page","ENTER",cursor==1)
  drawRow(y+s*(rows+2),"Previous Page","ENTER",cursor==2)

  lcd.drawText(LCD_W-70,250,"Page 2/4",SMLSIZE)

  -------------------------------------------------
  -- NAVIGATION
  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then cursor=cursor%2+1 end
  if event==EVT_VIRTUAL_PREV then cursor=(cursor-2)%2+1 end

  -------------------------------------------------
  -- ENTER ACTIONS
  -------------------------------------------------

  if event==EVT_VIRTUAL_ENTER then

    if cursor==1 then
      page=3
      cursor=1
      scanFiles()
      return 0

    elseif cursor==2 then
      page=1
      cursor=1
      return 0
    end

  end

end

-------------------------------------------------
-- PAGE 3 : FILE BROWSER
-------------------------------------------------

if page==3 then

  lcd.drawText(LCD_W/2,15,"Stick Log Browser",DBLSIZE + CENTER)
  lcd.drawLine(10,55,LCD_W-10,55,SOLID,0)

  local y=65
  local s=20
  local rows=7

  -------------------------------------------------
  -- FILTER DROPDOWN
  -------------------------------------------------

  drawRow(y,"File Filter",
          fileFilter==1 and "Last 20" or "All",
          cursor==1)

  -------------------------------------------------
  -- FILE LIST
  -------------------------------------------------

  for i=1,rows do

    local idx = fileScroll + i - 1
    local name = files[idx]

    if name then
      lcd.drawText(
        40,
        y + s*i,
        name,
        (cursor==(i+1) or files[idx]==selectedFile) and INVERS or 0
      )
    end

  end

  -------------------------------------------------
  -- CONTROLS
  -------------------------------------------------

  drawRow(y+s*(rows+1),"Next Page","ENTER",cursor==rows+2)
  drawRow(y+s*(rows+2),"Previous Page","ENTER",cursor==rows+3)

  lcd.drawText(LCD_W-70,250,"Page 3/4",SMLSIZE)

  -------------------------------------------------
  -- NAVIGATION (FIXED SCROLLING)
  -------------------------------------------------

  local maxCursor = rows + 3
  local maxScroll = math.max(1, #files - rows + 1)

  if event==EVT_VIRTUAL_NEXT then

    -- scroll down inside file list
    if cursor >= 2 and cursor <= rows+1 and cursor == rows+1 and fileScroll < maxScroll then
      fileScroll = fileScroll + 1
    else
      cursor = cursor % maxCursor + 1
    end

  end

  if event==EVT_VIRTUAL_PREV then

    -- scroll up inside file list
    if cursor >= 2 and cursor <= rows+1 and cursor == 2 and fileScroll > 1 then
      fileScroll = fileScroll - 1
    else
      cursor = (cursor - 2) % maxCursor + 1
    end

  end

  -------------------------------------------------
  -- ENTER ACTIONS
  -------------------------------------------------
  if event==EVT_VIRTUAL_ENTER then

  if cursor==1 then
    fileFilter = fileFilter % 2 + 1
    scanFiles()

  elseif cursor>=2 and cursor<=rows+1 then
    local idx = fileScroll + cursor - 2
    selectedFile = files[idx]

  elseif cursor==rows+2 then
    if selectedFile then
      page=4
      cursor=1
      baseTime = nil
      playbackData = {}
      playbackIndex = 1
      m10 = 0
      m1  = 0
      s10 = 0
      s1  = 0
      
      isPlaying = true
      loading = true
      
      fileHandle = io.open(logPath .. "/" .. selectedFile, "r")
      if not fileHandle then
        loading = false
        message = "Open failed"
      end
      
      buffer = ""
      return 0
    else
      message = "Select file"
    end

  elseif cursor==rows+3 then
    page=2
    cursor=1
    return 0
  end

end

end
-------------------------------------------------
-- PAGE 4 : STICK PLAYBACK
-------------------------------------------------

if page==4 then

  local motorIdx = model.getGlobalVariable(GV_INDEX, FM_MOTOR_IDX) or 1
  local motorVal = model.getGlobalVariable(GV_INDEX, FM_MOTOR_VAL) or 1024

  local armIdx = model.getGlobalVariable(GV_INDEX, FM_ARM_IDX) or 0
  local armVal = model.getGlobalVariable(GV_INDEX, FM_ARM_VAL) or 1024

  lcd.drawText(LCD_W/2,15,"Stick Movement Playback",DBLSIZE + CENTER)
  lcd.drawLine(10,55,LCD_W-10,55,SOLID,0)

  if loading or #playbackData < 2 then
    lcd.drawText(LCD_W/2, 70, "Loading...", CENTER + DBLSIZE)
    return 0
  end

  -------------------------------------------------
  -- BOX SETTINGS
  -------------------------------------------------

  local boxSize = 100
  local gap = 40

  local leftX  = 60
  local rightX = leftX + boxSize + gap

  local boxY = 90

  -------------------------------------------------
  -- LEFT BOX (THR / RUD)
  -------------------------------------------------

  lcd.drawRectangle(leftX, boxY, boxSize, boxSize)

  local cx1 = leftX + boxSize/2
  local cy1 = boxY + boxSize/2

  lcd.drawLine(cx1, boxY, cx1, boxY+boxSize, SOLID, 0)
  lcd.drawLine(leftX, cy1, leftX+boxSize, cy1, SOLID, 0)

  local frame = playbackData[playbackIndex] or {ch1=0,ch2=0,ch3=0,ch4=0,motor=0, arm=0, fm=0}
  local motorState = frame.motor or 0
  local armState = frame.arm or 0
  local fm = frame.fm or 0
  local fmText = "FM" .. tostring(fm)

  local motorText = (motorState == motorVal) and "MOTOR ON" or "MOTOR OFF"

  local armText
  if armIdx >= 1 then
    armText = (armState == armVal) and "ARMED" or "DISARMED"
  else
    armText = "ARM DISABLED"
  end
 
  local timeText = formatTime(frame.time or 0)
  lcd.drawText(leftX, boxY + boxSize + 10, "Time:", SMLSIZE)
  lcd.drawText(leftX + 40, boxY + boxSize + 10, timeText, SMLSIZE)

  lcd.drawText(leftX, boxY + boxSize + 25, "File:", SMLSIZE)
  lcd.drawText(leftX + 40, boxY + boxSize + 25, selectedFile or "-", SMLSIZE)

  lcd.drawText(rightX, boxY + boxSize + 10, fmText, SMLSIZE)

  local x1 = mapStick(frame.ch4, cx1, boxSize) -- rud = X
  local y1 = mapStick(-frame.ch3, cy1, boxSize) -- thr = Y (invert)
  lcd.drawFilledCircle(x1, y1, 4)

  -------------------------------------------------
  -- RIGHT BOX (AIL / ELE)
  -------------------------------------------------

  lcd.drawText(leftX + boxSize/2, boxY - 20, motorText, CENTER) 
  lcd.drawText(rightX + boxSize/2, boxY - 20, armText, CENTER)

  lcd.drawRectangle(rightX, boxY, boxSize, boxSize)

  local cx2 = rightX + boxSize/2
  local cy2 = boxY + boxSize/2

  lcd.drawLine(cx2, boxY, cx2, boxY+boxSize, SOLID, 0)
  lcd.drawLine(rightX, cy2, rightX+boxSize, cy2, SOLID, 0)

  local x2 = mapStick(frame.ch1, cx2, boxSize) -- ail
  local y2 = mapStick(-frame.ch2, cy2, boxSize) -- ele (invert)
  lcd.drawFilledCircle(x2, y2, 4)

  -------------------------------------------------
  -- CHANNEL LABELS
  -------------------------------------------------

  local labelX = rightX + boxSize + 20
  local labelY = boxY

  local lineSpacing = 18

  local function getName(src, fallback)
    local idx = getSourceIndex(src)
    if idx then return getSourceName(idx) end
    return fallback
  end

  local ailName = getName("ail", "AIL")
  local eleName = getName("ele", "ELE")
  local thrName = getName("thr", "THR")
  local rudName = getName("rud", "RUD")

  lcd.drawText(labelX, labelY + lineSpacing*0, "Ch1: " .. ailName)
  lcd.drawText(labelX, labelY + lineSpacing*1, "Ch2: " .. eleName)
  lcd.drawText(labelX, labelY + lineSpacing*2, "Ch3: " .. thrName)
  lcd.drawText(labelX, labelY + lineSpacing*3, "Ch4: " .. rudName)
  -------------------------------------------------
  -- TIME INPUT (USER)
  -------------------------------------------------

  lcd.drawText(labelX, labelY + lineSpacing*5, "Time:")


  lcd.drawText(labelX + 45, labelY + lineSpacing*5, tostring(m10), cursor==1 and INVERS or 0)
  lcd.drawText(labelX + 55, labelY + lineSpacing*5, tostring(m1), cursor==2 and INVERS or 0)
  lcd.drawText(labelX + 65, labelY + lineSpacing*5, ":")

  lcd.drawText(labelX + 70, labelY + lineSpacing*5, tostring(s10), cursor==3 and INVERS or 0)
  lcd.drawText(labelX + 80, labelY + lineSpacing*5, tostring(s1), cursor==4 and INVERS or 0)

  lcd.drawText(labelX + 95, labelY + lineSpacing*5, "[Jump]", cursor==5 and INVERS or 0)

  local btnY = boxY + boxSize + 45
  local playText = isPlaying and "[Pause]" or "[Play]"
  lcd.drawText(labelX, labelY + lineSpacing*6, playText, cursor==6 and INVERS or 0)

  lcd.drawText(40,240,"Exit")
  lcd.drawText(320,240,"EXIT", cursor==7 and INVERS or 0)

  -------------------------------------------------
  -- PLAYBACK ADVANCE
  -------------------------------------------------
  if isPlaying and #playbackData > 0 then

    local elapsed = (getTime() - playbackStartTime) * 10  

    while playbackIndex < #playbackData and
          playbackData[playbackIndex+1].time <= elapsed do
      playbackIndex = playbackIndex + 1
    end

    if playbackIndex >= #playbackData then
      playbackIndex = #playbackData
    end

  end

-------------------------------------------------
-- NAVIGATION AND ACTIONS
-------------------------------------------------

if event==EVT_VIRTUAL_NEXT then
  if cursor < 7 then cursor = cursor + 1 end
end

if event==EVT_VIRTUAL_PREV then
  if cursor > 1 then cursor = cursor - 1 end
end

if event == EVT_VIRTUAL_ENTER then

  if cursor == 1 then
    m10 = (m10 + 1) % 6   -- 0–5

  elseif cursor == 2 then
    m1 = (m1 + 1) % 10

  elseif cursor == 3 then
    s10 = (s10 + 1) % 6   

  elseif cursor == 4 then
    s1 = (s1 + 1) % 10

  elseif cursor == 5 then
    -- JUMP
    local minutes = m10 * 10 + m1
    local seconds = s10 * 10 + s1
    local targetMs = (minutes * 60 + seconds) * 1000

    for i = 1, #playbackData do
      if playbackData[i].time >= targetMs then
        playbackIndex = i
        playbackStartTime = getTime() - (playbackData[i].time / 10)
        break
      end
    end

  elseif cursor == 6 then
    if isPlaying then
      pausedTime = playbackData[playbackIndex].time or 0
      isPlaying = false

    else
      local currentTime = playbackData[playbackIndex].time or 0
      playbackStartTime = getTime() - (currentTime / 10)
      isPlaying = true

    end

  elseif cursor == 7 then
    page=3
    cursor=1
    return 0
  end

end

end

--------------------------------------------------

  return 0
end

return { run=run }