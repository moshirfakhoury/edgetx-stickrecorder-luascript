--Stick Recorder Designed & Written by Moshir Fakhoury (Youtube: Flywithmoshirrc)
--Background script - records stick movements into a .txt file 
--Version 2 - 04/05/2026
--No longer reads Global Variables, now reads model config file
--https://github.com/moshirfakhoury/edgetx-stickrecorder-luascript

-------------------------------------------------
-- CONSTANTS
-------------------------------------------------

local switches = {"SA","SB","SC","SD","SE","SF","SG","SH"}

local basePath = "/SCRIPTS/TOOLS/StickRecorder/"

local LOG_INTERVAL = 10 -- 10 rows per second

local modelName = model.getInfo().name
local safeName = string.gsub(modelName, "%W", "_")
local configPath = basePath .. "config_" .. safeName .. ".txt"

-------------------------------------------------
-- STATE
-------------------------------------------------

local lastOn = nil
local file = nil
local lastLogTime = 0

-------------------------------------------------
-- TIME HELPERS
-------------------------------------------------

local function nowTime()
  local t = getDateTime()
  local ms = (getTime() % 100) * 10
  return string.format("%02d:%02d:%02d.%03d", t.hour, t.min, t.sec, ms)
end

local function nowDate()
  local t = getDateTime()
  return string.format("%04d-%02d-%02d", t.year, t.mon, t.day)
end

local function fileTimestamp()
  local t = getDateTime()
  return string.format("%04d%02d%02d_%02d%02d%02d",
    t.year,t.mon,t.day,t.hour,t.min,t.sec)
end

-------------------------------------------------
-- READ CONFIG FILE
-------------------------------------------------
local function readConfig()

  local f = io.open(configPath, "r")
  if not f then return nil end

  local buffer = ""
  local values = {}

  while true do

    local chunk = io.read(f, 64)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer, "\n", 1, true)
      if not s then break end

      local line = string.sub(buffer, 1, s-1)
      buffer = string.sub(buffer, s+1)

      -- CLEAN LINE (important)
      line = string.gsub(line, "[^%-%d]", "")

      if line ~= "" then
        values[#values+1] = tonumber(line)
      end

    end

    if not chunk or chunk == "" then break end

  end

  io.close(f)

  -------------------------------------------------
  -- RETURN VALUES (only if valid)
  -------------------------------------------------

  if #values >= 6 then
    return values[1], values[2], values[3],
           values[4], values[5], values[6]
  end

  return nil
end
-------------------------------------------------
-- START LOGGING
-------------------------------------------------

local function startLog()

  local info = model.getInfo()
  if not info then return end

  local name = info.name .. "_" .. fileTimestamp() .. ".txt"
  local path = basePath .. name

  file = io.open(path,"w")

  if file then
    io.write(file,"date,time,ch1,ch2,ch3,ch4,motor,arm,fm\n")
  end

end

-------------------------------------------------
-- STOP LOGGING
-------------------------------------------------

local function stopLog()

  if file then
    io.close(file)
    file = nil
  end

end

-------------------------------------------------
-- WRITE STICK DATA
-------------------------------------------------

local function logSticks(motorIdx, motorVal, armIdx, armVal, switchIdx, switchVal)

  if not switches[motorIdx] then return end
  if armIdx >= 1 and not switches[armIdx] then return end

  if not file then return end

  local ch1 = getValue("ail") or 0
  local ch2 = getValue("ele") or 0
  local ch3 = getValue("thr") or 0
  local ch4 = getValue("rud") or 0

  local fm = getFlightMode() or 0

  local srcM = getSourceIndex(string.lower(switches[motorIdx]))
  local motorRaw = srcM and getValue(srcM) or 0

  local srcA = (armIdx >= 1) and getSourceIndex(string.lower(switches[armIdx])) or nil
  local armRaw = (srcA and getValue(srcA)) or 0

  local motorState = (motorRaw > 0) and 1024 or -1024
  local armState   = (armIdx >= 1 and armRaw > 0) and 1024 or -1024

  local line = string.format(
    "%s,%s,%d,%d,%d,%d,%d,%d,%d\n",
    nowDate(),
    nowTime(),
    ch1,ch2,ch3,ch4,
    motorState,
    armState,
    fm
  )

  io.write(file,line)

end

-------------------------------------------------
-- MAIN LOOP
-------------------------------------------------

local function run()

  local motorIdx, motorVal, armIdx, armVal, switchIdx, switchVal = readConfig()

  if not switchIdx then return end
  if not switchVal then return end
  if not switches[switchIdx] then return end

  -------------------------------------------------
  -- enable
  -------------------------------------------------

local switchRaw = getValue(switches[switchIdx]) or 0

  local enableOn =
      (switchVal > 0 and switchRaw > 0) or
      (switchVal < 0 and switchRaw < 0)
  
  if lastOn == nil then
    lastOn = enableOn
    return
  end

  if enableOn and not lastOn then
    startLog()
  end

  if not enableOn and lastOn then
    stopLog()
  end

  if enableOn and file then
  
    local now = getTime()

    if now - lastLogTime > LOG_INTERVAL then
      logSticks(motorIdx, motorVal, armIdx, armVal, switchIdx, switchVal)
      lastLogTime = now
    end

  end

  lastOn = enableOn

end

-------------------------------------------------

return { run = run }